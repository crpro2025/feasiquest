// Global State Management
const appState = {
    userProfile: {
        role: null,
        experience: null,
        objective: null,
        xp: 0,
        level: 'Novice',
        completedModules: [],
        badges: []
    },
    currentModule: null,
    moduleProgress: {}
};

// Level thresholds
const levelThresholds = {
    'Novice': 0,
    'Analyst': 500,
    'Expert': 1500,
    'Feasibility Master': 3000
};

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    loadUserProgress();
    updateProgressDisplay();
});

// Start Assessment
function startAssessment() {
    document.getElementById('welcome').classList.add('hidden');
    document.getElementById('assessment').classList.remove('hidden');
    document.getElementById('assessment').classList.add('fade-in');
}

// Submit Assessment
function submitAssessment() {
    const role = document.querySelector('input[name="role"]:checked');
    const experience = document.querySelector('input[name="experience"]:checked');
    const objective = document.querySelector('input[name="objective"]:checked');

    if (!role || !experience || !objective) {
        alert('Please complete all questions before continuing.');
        return;
    }

    appState.userProfile.role = role.value;
    appState.userProfile.experience = experience.value;
    appState.userProfile.objective = objective.value;

    saveUserProgress();

    document.getElementById('assessment').classList.add('hidden');
    document.getElementById('dashboard').classList.remove('hidden');
    document.getElementById('dashboard').classList.add('fade-in');
}

// Start Module
function startModule(moduleNumber) {
    const moduleCard = event.currentTarget;
    if (moduleCard.classList.contains('locked')) {
        alert('Complete previous modules to unlock this one.');
        return;
    }

    appState.currentModule = moduleNumber;
    
    document.getElementById('dashboard').classList.add('hidden');
    document.getElementById('moduleContent').classList.remove('hidden');
    
    loadModuleContent(moduleNumber);
}

// Load Module Content
function loadModuleContent(moduleNumber) {
    const contentArea = document.getElementById('moduleContent');
    
    switch(moduleNumber) {
        case 1:
            loadModule1Content(contentArea);
            break;
        case 2:
            loadModule2Content(contentArea);
            break;
        case 3:
            loadModule3Content(contentArea);
            break;
        case 4:
            loadModule4Content(contentArea);
            break;
        case 5:
            loadModule5Content(contentArea);
            break;
        default:
            contentArea.innerHTML = '<h2>Module content coming soon...</h2>';
    }
}

// Module 1: Feasibility Foundations
function loadModule1Content(container) {
    const isNovice = appState.userProfile.experience === 'novice';
    
    container.innerHTML = `
        <div class="module-header-section">
            <button class="btn btn-secondary" onclick="returnToDashboard()">← Back to Dashboard</button>
            <h1>Module 1: Feasibility Foundations</h1>
            <p class="module-subtitle">Understanding why feasibility matters and the cost of getting it wrong</p>
        </div>

        <div class="step-indicator">
            <div class="step active">
                <div class="step-circle">1</div>
                <div class="step-label">Introduction</div>
            </div>
            <div class="step">
                <div class="step-circle">2</div>
                <div class="step-label">Case Studies</div>
            </div>
            <div class="step">
                <div class="step-circle">3</div>
                <div class="step-label">Practice</div>
            </div>
            <div class="step">
                <div class="step-circle">4</div>
                <div class="step-label">Assessment</div>
            </div>
        </div>

        <div id="module1-content">
            ${getModule1IntroContent(isNovice)}
        </div>
    `;
}

function getModule1IntroContent(isNovice) {
    return `
        <div class="scenario-container">
            <h2 class="scenario-title">💡 The $2.6 Billion Question</h2>
            <div class="scenario-content">
                <p style="font-size: 1.2rem; margin-bottom: 20px;">
                    It costs an average of <strong>$2.6 billion</strong> to bring a new drug to market. 
                    Yet <strong>68% of clinical trials fail to meet their enrollment targets</strong>, 
                    leading to delays, budget overruns, and sometimes complete trial failure.
                </p>
                <p style="font-size: 1.1rem;">
                    What if we could predict and prevent these failures before they happen? 
                    That's the power of proper feasibility assessment.
                </p>
            </div>
        </div>

        <div class="interactive-card">
            <h3>🎯 What is Feasibility Assessment?</h3>
            <p style="margin: 20px 0;">
                Feasibility assessment is the systematic evaluation of whether a clinical trial can be 
                successfully executed as designed. It examines multiple dimensions:
            </p>
            
            <div class="feasibility-dimensions">
                <div class="dimension-card">
                    <div class="dimension-icon">👥</div>
                    <h4>Patient Population</h4>
                    <p>Can we find and enroll enough eligible patients?</p>
                </div>
                <div class="dimension-card">
                    <div class="dimension-icon">🏥</div>
                    <h4>Site Capability</h4>
                    <p>Do sites have the resources and expertise needed?</p>
                </div>
                <div class="dimension-card">
                    <div class="dimension-icon">📋</div>
                    <h4>Regulatory</h4>
                    <p>Can we navigate regulatory requirements successfully?</p>
                </div>
                <div class="dimension-card">
                    <div class="dimension-icon">💰</div>
                    <h4>Budget & Resources</h4>
                    <p>Is the trial financially viable?</p>
                </div>
                <div class="dimension-card">
                    <div class="dimension-icon">⚡</div>
                    <h4>Timeline</h4>
                    <p>Can we complete the trial within required timeframes?</p>
                </div>
                <div class="dimension-card">
                    <div class="dimension-icon">🔬</div>
                    <h4>Technology</h4>
                    <p>Do we have the right infrastructure and systems?</p>
                </div>
            </div>
        </div>

        <div class="interactive-card" style="margin-top: 30px;">
            <h3>📊 The Cost of Poor Feasibility</h3>
            <p style="margin: 20px 0;">
                Let's explore real-world examples of what happens when feasibility is overlooked:
            </p>
            
            <div class="case-study-selector">
                <button class="case-study-btn" onclick="showCaseStudy(1)">
                    Case Study 1: The Alzheimer's Mega-Trial
                </button>
                <button class="case-study-btn" onclick="showCaseStudy(2)">
                    Case Study 2: The Rare Disease Rush
                </button>
                <button class="case-study-btn" onclick="showCaseStudy(3)">
                    Case Study 3: The Perfect Protocol Problem
                </button>
            </div>

            <div id="case-study-content" style="margin-top: 30px;">
                <p style="text-align: center; color: #6b7280; font-style: italic;">
                    Select a case study above to begin
                </p>
            </div>
        </div>

        <div class="nav-buttons">
            <button class="btn btn-secondary" onclick="returnToDashboard()">Save & Exit</button>
            <button class="btn btn-primary" onclick="continueToStep2()">Continue to Case Studies →</button>
        </div>

        <style>
        .module-header-section {
            margin-bottom: 40px;
        }

        .module-header-section h1 {
            font-size: 2.5rem;
            color: var(--text-primary);
            margin: 20px 0 10px;
        }

        .module-subtitle {
            font-size: 1.2rem;
            color: var(--text-secondary);
        }

        .feasibility-dimensions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }

        .dimension-card {
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
            border: 2px solid #bfdbfe;
            border-radius: 12px;
            padding: 25px;
            text-align: center;
            transition: all 0.3s ease;
        }

        .dimension-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
            border-color: var(--primary-color);
        }

        .dimension-icon {
            font-size: 3rem;
            margin-bottom: 15px;
        }

        .dimension-card h4 {
            color: var(--primary-color);
            font-size: 1.2rem;
            margin-bottom: 10px;
        }

        .dimension-card p {
            color: var(--text-secondary);
            font-size: 0.95rem;
            line-height: 1.5;
        }

        .case-study-selector {
            display: grid;
            gap: 15px;
        }

        .case-study-btn {
            background: white;
            border: 2px solid var(--border-color);
            border-radius: 10px;
            padding: 20px;
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--text-primary);
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: left;
        }

        .case-study-btn:hover {
            border-color: var(--primary-color);
            background: var(--bg-light);
            transform: translateX(10px);
        }

        .case-study-btn:active {
            transform: translateX(5px);
        }
        </style>
    `;
}

// Case Study Display
function showCaseStudy(caseNumber) {
    const contentDiv = document.getElementById('case-study-content');
    
    const caseStudies = {
        1: {
            title: "The Alzheimer's Mega-Trial: A $200M Lesson",
            problem: "A large pharmaceutical company launched an ambitious Phase III Alzheimer's trial across 150 sites globally. The protocol was scientifically sound, the drug showed promise, but they overlooked critical feasibility factors.",
            issues: [
                "Site readiness was overestimated - only 40% of sites were actually ready at study start",
                "Specialized imaging requirements exceeded most sites' capabilities",
                "Caregiver burden was underestimated, leading to high dropout rates",
                "Competing trials launched simultaneously, fragmenting the patient pool"
            ],
            impact: "18-month delay, $200M budget overrun, and ultimately the trial was restructured",
            lesson: "Even with unlimited resources, poor feasibility assessment leads to failure. Site capability and competitive landscape must be thoroughly evaluated."
        },
        2: {
            title: "The Rare Disease Rush: When Numbers Don't Add Up",
            problem: "A biotech company developed a promising therapy for an ultra-rare genetic disorder. Excited by the science, they rushed into a Phase II trial without proper patient population analysis.",
            issues: [
                "Overestimated patient population by 300% based on outdated epidemiological data",
                "Failed to account for 3 competing trials recruiting from the same small patient pool",
                "Didn't consider that 60% of eligible patients were already enrolled in other studies",
                "Geographic distribution of patients made site selection nearly impossible"
            ],
            impact: "Trial enrollment took 4 years instead of planned 18 months. Company nearly went bankrupt waiting for enrollment.",
            lesson: "In rare diseases, every patient counts. Thorough epidemiological analysis and competitive intelligence are non-negotiable."
        },
        3: {
            title: "The Perfect Protocol Problem: When Science Meets Reality",
            problem: "A cardiovascular outcomes trial was designed with rigorous inclusion/exclusion criteria to ensure a homogeneous patient population and clean data. The protocol was scientifically perfect but practically impossible.",
            issues: [
                "Inclusion criteria so restrictive that only 12% of screened patients qualified",
                "Required 15 study visits over 2 years - patient burden was unsustainable",
                "Mandated procedures not covered by insurance, creating financial barriers",
                "Protocol amendments required after 6 months, resetting regulatory timelines"
            ],
            impact: "Enrollment rate was 1/10th of projection. Trial was ultimately terminated after 2 years with insufficient data.",
            lesson: "Scientific rigor must be balanced with practical feasibility. The perfect protocol that can't enroll patients is worthless."
        }
    };

    const study = caseStudies[caseNumber];
    
    contentDiv.innerHTML = `
        <div class="case-study-detail fade-in">
            <h3 style="color: var(--primary-color); margin-bottom: 20px;">${study.title}</h3>
            
            <div class="case-section">
                <h4>📋 The Situation</h4>
                <p>${study.problem}</p>
            </div>

            <div class="case-section">
                <h4>⚠️ What Went Wrong</h4>
                <ul>
                    ${study.issues.map(issue => `<li>${issue}</li>`).join('')}
                </ul>
            </div>

            <div class="case-section">
                <h4>💥 The Impact</h4>
                <p style="color: var(--danger-color); font-weight: 600;">${study.impact}</p>
            </div>

            <div class="case-section" style="background: #d1fae5; padding: 20px; border-radius: 10px; border-left: 5px solid var(--secondary-color);">
                <h4>✅ Key Lesson</h4>
                <p style="color: #065f46; font-weight: 500;">${study.lesson}</p>
            </div>

            <div class="reflection-box">
                <h4>🤔 Reflection Question</h4>
                <p>If you were the feasibility lead on this trial, what would you have done differently?</p>
                <textarea class="reflection-input" placeholder="Type your thoughts here..." rows="4"></textarea>
                <button class="btn btn-primary" onclick="saveReflection(${caseNumber})">Save Reflection</button>
            </div>
        </div>

        <style>
        .case-study-detail {
            background: white;
            border: 2px solid var(--border-color);
            border-radius: 15px;
            padding: 30px;
        }

        .case-section {
            margin: 25px 0;
        }

        .case-section h4 {
            font-size: 1.2rem;
            margin-bottom: 15px;
            color: var(--text-primary);
        }

        .case-section ul {
            list-style: none;
            padding-left: 0;
        }

        .case-section li {
            padding: 10px 0 10px 30px;
            position: relative;
            line-height: 1.6;
        }

        .case-section li::before {
            content: "→";
            position: absolute;
            left: 0;
            color: var(--primary-color);
            font-weight: bold;
        }

        .reflection-box {
            margin-top: 30px;
            background: var(--bg-light);
            padding: 25px;
            border-radius: 10px;
        }

        .reflection-input {
            width: 100%;
            padding: 15px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            font-family: inherit;
            font-size: 1rem;
            margin: 15px 0;
            resize: vertical;
        }

        .reflection-input:focus {
            outline: none;
            border-color: var(--primary-color);
        }
        </style>
    `;
}

function saveReflection(caseNumber) {
    const reflection = document.querySelector('.reflection-input').value;
    if (reflection.trim()) {
        showFeedback('Reflection saved! Great thinking.', 'success');
        awardXP(25);
    } else {
        alert('Please write your reflection before saving.');
    }
}

// Continue to Step 2
function continueToStep2() {
    const contentDiv = document.getElementById('module1-content');
    updateStepIndicator(2);
    
    contentDiv.innerHTML = `
        <div class="interactive-card">
            <h2>🎓 Deep Dive: Feasibility Assessment Framework</h2>
            <p style="margin: 20px 0; font-size: 1.1rem;">
                Now that you understand why feasibility matters, let's explore the systematic approach 
                to conducting feasibility assessments.
            </p>

            <div class="framework-section">
                <h3>The Five Pillars of Feasibility</h3>
                <div class="pillars-grid">
                    <div class="pillar-card" onclick="explorePillar(1)">
                        <div class="pillar-number">1</div>
                        <h4>Scientific Feasibility</h4>
                        <p>Is the science sound? Are endpoints achievable?</p>
                        <button class="explore-btn">Explore →</button>
                    </div>
                    <div class="pillar-card" onclick="explorePillar(2)">
                        <div class="pillar-number">2</div>
                        <h4>Operational Feasibility</h4>
                        <p>Can we execute this operationally?</p>
                        <button class="explore-btn">Explore →</button>
                    </div>
                    <div class="pillar-card" onclick="explorePillar(3)">
                        <div class="pillar-number">3</div>
                        <h4>Financial Feasibility</h4>
                        <p>Is this financially viable?</p>
                        <button class="explore-btn">Explore →</button>
                    </div>
                    <div class="pillar-card" onclick="explorePillar(4)">
                        <div class="pillar-number">4</div>
                        <h4>Regulatory Feasibility</h4>
                        <p>Can we meet regulatory requirements?</p>
                        <button class="explore-btn">Explore →</button>
                    </div>
                    <div class="pillar-card" onclick="explorePillar(5)">
                        <div class="pillar-number">5</div>
                        <h4>Strategic Feasibility</h4>
                        <p>Does this align with business strategy?</p>
                        <button class="explore-btn">Explore →</button>
                    </div>
                </div>
            </div>

            <div id="pillar-detail" style="margin-top: 40px;">
                <p style="text-align: center; color: #6b7280; font-style: italic;">
                    Click on any pillar above to learn more
                </p>
            </div>
        </div>

        <div class="nav-buttons">
            <button class="btn btn-secondary" onclick="loadModule1Content(document.getElementById('moduleContent'))">← Previous</button>
            <button class="btn btn-primary" onclick="continueToStep3()">Continue to Practice →</button>
        </div>

        <style>
        .framework-section {
            margin: 30px 0;
        }

        .pillars-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }

        .pillar-card {
            background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
            border: 2px solid #fbbf24;
            border-radius: 15px;
            padding: 25px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
        }

        .pillar-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.15);
        }

        .pillar-number {
            position: absolute;
            top: -15px;
            left: 50%;
            transform: translateX(-50%);
            width: 40px;
            height: 40px;
            background: var(--accent-color);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 1.2rem;
        }

        .pillar-card h4 {
            margin: 20px 0 10px;
            color: #92400e;
            font-size: 1.1rem;
        }

        .pillar-card p {
            color: #78350f;
            font-size: 0.9rem;
            margin-bottom: 15px;
        }

        .explore-btn {
            background: white;
            border: 2px solid #fbbf24;
            color: #92400e;
            padding: 8px 20px;
            border-radius: 20px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .explore-btn:hover {
            background: #fbbf24;
            color: white;
        }
        </style>
    `;
}

function explorePillar(pillarNumber) {
    const detailDiv = document.getElementById('pillar-detail');
    
    const pillars = {
        1: {
            title: "Scientific Feasibility",
            description: "Evaluating whether the scientific foundation of the trial is sound and achievable.",
            components: [
                "Endpoint selection and measurability",
                "Biomarker validation and reliability",
                "Disease progression understanding",
                "Treatment effect size expectations",
                "Statistical power and sample size justification"
            ],
            questions: [
                "Are the endpoints clinically meaningful and measurable?",
                "Do we have validated tools to assess outcomes?",
                "Is the expected treatment effect realistic?",
                "Can we detect the effect with the proposed sample size?"
            ]
        },
        2: {
            title: "Operational Feasibility",
            description: "Assessing whether the trial can be executed with available resources and infrastructure.",
            components: [
                "Site identification and qualification",
                "Patient recruitment and retention strategies",
                "Study procedures and visit schedules",
                "Supply chain and logistics",
                "Data management and monitoring"
            ],
            questions: [
                "Do we have enough qualified sites?",
                "Can we recruit patients within timeline?",
                "Are study procedures practical for sites and patients?",
                "Do we have robust supply chain management?"
            ]
        },
        3: {
            title: "Financial Feasibility",
            description: "Determining if the trial is financially viable and provides acceptable ROI.",
            components: [
                "Budget development and validation",
                "Cost-benefit analysis",
                "Resource allocation",
                "Cash flow management",
                "ROI projections"
            ],
            questions: [
                "Is the budget realistic and complete?",
                "What is the expected ROI?",
                "Are there hidden costs we haven't considered?",
                "Can we afford delays or protocol amendments?"
            ]
        },
        4: {
            title: "Regulatory Feasibility",
            description: "Ensuring the trial can meet all regulatory requirements and timelines.",
            components: [
                "Regulatory pathway selection",
                "Submission strategy and timing",
                "Compliance requirements",
                "Regional regulatory differences",
                "Post-approval commitments"
            ],
            questions: [
                "What is the optimal regulatory pathway?",
                "Are timelines realistic for regulatory approvals?",
                "Do we understand regional requirements?",
                "What are the risks of regulatory delays?"
            ]
        },
        5: {
            title: "Strategic Feasibility",
            description: "Aligning the trial with overall business strategy and market positioning.",
            components: [
                "Market opportunity assessment",
                "Competitive landscape analysis",
                "Portfolio fit and prioritization",
                "Partnership opportunities",
                "Commercial viability"
            ],
            questions: [
                "Does this trial support our strategic goals?",
                "What is the competitive advantage?",
                "How does this fit in our portfolio?",
                "What is the market potential?"
            ]
        }
    };

    const pillar = pillars[pillarNumber];
    
    detailDiv.innerHTML = `
        <div class="pillar-detail-card fade-in">
            <h3 style="color: var(--accent-color); margin-bottom: 15px;">
                ${pillarNumber}. ${pillar.title}
            </h3>
            <p style="font-size: 1.1rem; margin-bottom: 25px; color: var(--text-secondary);">
                ${pillar.description}
            </p>

            <div class="detail-section">
                <h4>Key Components</h4>
                <ul class="component-list">
                    ${pillar.components.map(comp => `<li>${comp}</li>`).join('')}
                </ul>
            </div>

            <div class="detail-section">
                <h4>Critical Questions to Ask</h4>
                <div class="questions-grid">
                    ${pillar.questions.map(q => `
                        <div class="question-card">
                            <span class="question-icon">❓</span>
                            <p>${q}</p>
                        </div>
                    `).join('')}
                </div>
            </div>
        </div>

        <style>
        .pillar-detail-card {
            background: white;
            border: 3px solid var(--accent-color);
            border-radius: 15px;
            padding: 35px;
        }

        .detail-section {
            margin: 30px 0;
        }

        .detail-section h4 {
            font-size: 1.3rem;
            color: var(--text-primary);
            margin-bottom: 20px;
        }

        .component-list {
            list-style: none;
            padding: 0;
        }

        .component-list li {
            padding: 12px 0 12px 35px;
            position: relative;
            border-bottom: 1px solid var(--border-color);
        }

        .component-list li::before {
            content: "✓";
            position: absolute;
            left: 0;
            color: var(--secondary-color);
            font-weight: bold;
            font-size: 1.2rem;
        }

        .questions-grid {
            display: grid;
            gap: 15px;
        }

        .question-card {
            background: var(--bg-light);
            border-left: 4px solid var(--primary-color);
            padding: 15px 15px 15px 50px;
            border-radius: 8px;
            position: relative;
        }

        .question-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 1.5rem;
        }

        .question-card p {
            margin: 0;
            color: var(--text-primary);
            font-weight: 500;
        }
        </style>
    `;
    
    awardXP(10);
}

// Continue to Step 3 - Practice Exercise
function continueToStep3() {
    const contentDiv = document.getElementById('module1-content');
    updateStepIndicator(3);
    
    contentDiv.innerHTML = `
        <div class="interactive-card">
            <h2>🎯 Practice Exercise: Protocol Synopsis Analysis</h2>
            <p style="margin: 20px 0; font-size: 1.1rem;">
                Now it's time to apply what you've learned. Review the protocol synopsis below and 
                identify potential feasibility issues.
            </p>

            <div class="protocol-synopsis">
                <h3>Protocol Synopsis: CARDIO-2025</h3>
                <div class="synopsis-content">
                    <div class="synopsis-section">
                        <h4>Study Title</h4>
                        <p>A Phase III, Randomized, Double-Blind, Placebo-Controlled Study of Novel-Drug-X 
                        in Patients with Advanced Heart Failure</p>
                    </div>

                    <div class="synopsis-section">
                        <h4>Study Objectives</h4>
                        <p>Primary: To evaluate the effect of Novel-Drug-X on cardiovascular mortality 
                        and heart failure hospitalization over 24 months</p>
                    </div>

                    <div class="synopsis-section">
                        <h4>Study Population</h4>
                        <p><strong>Target Enrollment:</strong> 5,000 patients globally</p>
                        <p><strong>Key Inclusion Criteria:</strong></p>
                        <ul>
                            <li>Age 18-75 years</li>
                            <li>NYHA Class III-IV heart failure</li>
                            <li>LVEF ≤ 30%</li>
                            <li>NT-proBNP > 1000 pg/mL</li>
                            <li>On stable optimal medical therapy for ≥ 3 months</li>
                            <li>Specific genetic biomarker present (prevalence ~15% in HF population)</li>
                            <li>No hospitalization in past 30 days</li>
                        </ul>
                        <p><strong>Key Exclusion Criteria:</strong></p>
                        <ul>
                            <li>Recent MI or stroke (< 90 days)</li>
                            <li>Severe renal impairment (eGFR < 30)</li>
                            <li>Liver disease</li>
                            <li>Currently enrolled in another trial</li>
                        </ul>
                    </div>

                    <div class="synopsis-section">
                        <h4>Study Design</h4>
                        <p>Duration: 24 months treatment + 6 months follow-up</p>
                        <p>Number of Sites: 200 sites across 25 countries</p>
                        <p>Visit Schedule: Screening, Baseline, then monthly visits for first 6 months, 
                        then quarterly visits</p>
                    </div>

                    <div class="synopsis-section">
                        <h4>Study Procedures</h4>
                        <ul>
                            <li>Echocardiography at baseline, 6, 12, 18, and 24 months</li>
                            <li>Cardiac MRI at baseline and 24 months</li>
                            <li>6-minute walk test at each visit</li>
                            <li>Quality of life questionnaires</li>
                            <li>Extensive safety labs including genetic testing</li>
                            <li>24-hour Holter monitoring quarterly</li>
                        </ul>
                    </div>

                    <div class="synopsis-section">
                        <h4>Timeline</h4>
                        <p>Enrollment Period: 18 months</p>
                        <p>Total Study Duration: 48 months</p>
                    </div>
                </div>
            </div>

            <div class="exercise-section">
                <h3>🔍 Your Task: Identify Feasibility Red Flags</h3>
                <p>Review the protocol above and identify potential feasibility issues. 
                Click on the categories below to flag concerns:</p>

                <div class="red-flags-grid">
                    <div class="flag-category" onclick="toggleFlag('patient')">
                        <div class="flag-icon">👥</div>
                        <h4>Patient Population</h4>
                        <div class="flag-count" id="patient-count">0 issues identified</div>
                    </div>
                    <div class="flag-category" onclick="toggleFlag('site')">
                        <div class="flag-icon">🏥</div>
                        <h4>Site Capability</h4>
                        <div class="flag-count" id="site-count">0 issues identified</div>
                    </div>
                    <div class="flag-category" onclick="toggleFlag('timeline')">
                        <div class="flag-icon">⏱️</div>
                        <h4>Timeline</h4>
                        <div class="flag-count" id="timeline-count">0 issues identified</div>
                    </div>
                    <div class="flag-category" onclick="toggleFlag('procedures')">
                        <div class="flag-icon">🔬</div>
                        <h4>Procedures</h4>
                        <div class="flag-count" id="procedures-count">0 issues identified</div>
                    </div>
                </div>

                <div id="flag-details" style="margin-top: 30px;"></div>

                <button class="btn btn-success" onclick="submitFeasibilityAnalysis()" style="margin-top: 30px; width: 100%;">
                    Submit Analysis
                </button>
            </div>
        </div>

        <div class="nav-buttons">
            <button class="btn btn-secondary" onclick="continueToStep2()">← Previous</button>
            <button class="btn btn-primary" onclick="continueToStep4()">Continue to Assessment →</button>
        </div>

        <style>
        .protocol-synopsis {
            background: #f0f9ff;
            border: 2px solid #3b82f6;
            border-radius: 15px;
            padding: 30px;
            margin: 30px 0;
        }

        .protocol-synopsis h3 {
            color: var(--primary-color);
            margin-bottom: 25px;
            font-size: 1.5rem;
        }

        .synopsis-section {
            margin: 25px 0;
            padding: 20px;
            background: white;
            border-radius: 10px;
        }

        .synopsis-section h4 {
            color: var(--text-primary);
            margin-bottom: 15px;
            font-size: 1.2rem;
        }

        .synopsis-section ul {
            margin-left: 20px;
        }

        .synopsis-section li {
            margin: 8px 0;
            line-height: 1.6;
        }

        .exercise-section {
            margin-top: 40px;
        }

        .red-flags-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }

        .flag-category {
            background: white;
            border: 3px solid var(--border-color);
            border-radius: 15px;
            padding: 25px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .flag-category:hover {
            border-color: var(--danger-color);
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }

        .flag-category.flagged {
            border-color: var(--danger-color);
            background: #fee2e2;
        }

        .flag-icon {
            font-size: 3rem;
            margin-bottom: 15px;
        }

        .flag-category h4 {
            color: var(--text-primary);
            margin-bottom: 10px;
        }

        .flag-count {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }
        </style>
    `;
}

// Flag tracking
const flaggedIssues = {
    patient: [],
    site: [],
    timeline: [],
    procedures: []
};

function toggleFlag(category) {
    const issues = {
        patient: [
            "Genetic biomarker requirement (15% prevalence) significantly reduces eligible population",
            "Multiple restrictive inclusion criteria compound to very small eligible pool",
            "Target enrollment of 5,000 may be unrealistic given criteria",
            "Stable therapy requirement may exclude recently diagnosed patients"
        ],
        site: [
            "Cardiac MRI capability not available at all sites",
            "Genetic testing infrastructure may be limited",
            "200 sites may be insufficient given restrictive criteria",
            "Advanced heart failure expertise required - limits site pool"
        ],
        timeline: [
            "18-month enrollment period aggressive for 5,000 patients with rare biomarker",
            "Monthly visits for 6 months may impact retention",
            "48-month total duration increases dropout risk",
            "Enrollment timeline doesn't account for site activation delays"
        ],
        procedures: [
            "Cardiac MRI adds significant cost and patient burden",
            "Monthly visits in first 6 months may be excessive",
            "Multiple specialized procedures limit site capability",
            "24-hour Holter monitoring quarterly adds complexity"
        ]
    };

    const detailDiv = document.getElementById('flag-details');
    const category Element = event.currentTarget;
    
    if (!categoryElement.classList.contains('flagged')) {
        categoryElement.classList.add('flagged');
        flaggedIssues[category] = issues[category];
        
        detailDiv.innerHTML += `
            <div class="issue-detail fade-in" id="${category}-detail">
                <h4>⚠️ ${category.charAt(0).toUpperCase() + category.slice(1)} Issues Identified:</h4>
                <ul>
                    ${issues[category].map(issue => `<li>${issue}</li>`).join('')}
                </ul>
            </div>
        `;
        
        document.getElementById(`${category}-count`).textContent = `${issues[category].length} issues identified`;
        awardXP(25);
    } else {
        categoryElement.classList.remove('flagged');
        flaggedIssues[category] = [];
        document.getElementById(`${category}-detail`).remove();
        document.getElementById(`${category}-count`).textContent = '0 issues identified';
    }
}

function submitFeasibilityAnalysis() {
    const totalIssues = Object.values(flaggedIssues).flat().length;
    
    if (totalIssues === 0) {
        alert('Please identify at least one feasibility issue before submitting.');
        return;
    }

    const feedback = totalIssues >= 10 ? 'excellent' : totalIssues >= 6 ? 'good' : 'needs improvement';
    const xpReward = totalIssues >= 10 ? 100 : totalIssues >= 6 ? 75 : 50;
    
    showFeedback(`
        <h3>Analysis Complete!</h3>
        <p>You identified <strong>${totalIssues}</strong> feasibility issues.</p>
        <p>Performance: <strong>${feedback.toUpperCase()}</strong></p>
        <p>This protocol has significant feasibility challenges that would need to be addressed before study start.</p>
    `, 'success');
    
    awardXP(xpReward);
    
    // Unlock next step
    setTimeout(() => {
        continueToStep4();
    }, 3000);
}

// Continue to Step 4 - Final Assessment
function continueToStep4() {
    const contentDiv = document.getElementById('module1-content');
    updateStepIndicator(4);
    
    contentDiv.innerHTML = `
        <div class="interactive-card">
            <h2>📝 Module 1 Assessment</h2>
            <p style="margin: 20px 0; font-size: 1.1rem;">
                Test your understanding of feasibility foundations with this quick assessment.
            </p>

            <div class="quiz-container">
                <div class="quiz-question">
                    <h4>Question 1: What percentage of clinical trials fail to meet enrollment targets?</h4>
                    <div class="quiz-options">
                        <div class="quiz-option" onclick="selectAnswer(this, 'q1', false)">
                            A) 25%
                        </div>
                        <div class="quiz-option" onclick="selectAnswer(this, 'q1', false)">
                            B) 45%
                        </div>
                        <div class="quiz-option" onclick="selectAnswer(this, 'q1', true)">
                            C) 68%
                        </div>
                        <div class="quiz-option" onclick="selectAnswer(this, 'q1', false)">
                            D) 85%
                        </div>
                    </div>
                    <div class="answer-feedback" id="q1-feedback"></div>
                </div>

                <div class="quiz-question">
                    <h4>Question 2: Which of the following is NOT one of the five pillars of feasibility?</h4>
                    <div class="quiz-options">
                        <div class="quiz-option" onclick="selectAnswer(this, 'q2', false)">
                            A) Scientific Feasibility
                        </div>
                        <div class="quiz-option" onclick="selectAnswer(this, 'q2', false)">
                            B) Operational Feasibility
                        </div>
                        <div class="quiz-option" onclick="selectAnswer(this, 'q2', true)">
                            C) Marketing Feasibility
                        </div>
                        <div class="quiz-option" onclick="selectAnswer(this, 'q2', false)">
                            D) Regulatory Feasibility
                        </div>
                    </div>
                    <div class="answer-feedback" id="q2-feedback"></div>
                </div>

                <div class="quiz-question">
                    <h4>Question 3: In the Alzheimer's Mega-Trial case study, what was the primary feasibility issue?</h4>
                    <div class="quiz-options">
                        <div class="quiz-option" onclick="selectAnswer(this, 'q3', false)">
                            A) Insufficient budget
                        </div>
                        <div class="quiz-option" onclick="selectAnswer(this, 'q3', true)">
                            B) Site readiness was overestimated
                        </div>
                        <div class="quiz-option" onclick="selectAnswer(this, 'q3', false)">
                            C) Regulatory delays
                        </div>
                        <div class="quiz-option" onclick="selectAnswer(this, 'q3', false)">
                            D) Drug supply issues
                        </div>
                    </div>
                    <div class="answer-feedback" id="q3-feedback"></div>
                </div>

                <div class="quiz-question">
                    <h4>Question 4: What is the primary purpose of feasibility assessment?</h4>
                    <div class="quiz-options">
                        <div class="quiz-option" onclick="selectAnswer(this, 'q4', false)">
                            A) To satisfy regulatory requirements
                        </div>
                        <div class="quiz-option" onclick="selectAnswer(this, 'q4', true)">
                            B) To predict and prevent trial failures before they happen
                        </div>
                        <div class="quiz-option" onclick="selectAnswer(this, 'q4', false)">
                            C) To reduce trial costs
                        </div>
                        <div class="quiz-option" onclick="selectAnswer(this, 'q4', false)">
                            D) To speed up enrollment
                        </div>
                    </div>
                    <div class="answer-feedback" id="q4-feedback"></div>
                </div>

                <div class="quiz-question">
                    <h4>Question 5: Which factor was the main issue in "The Perfect Protocol Problem" case study?</h4>
                    <div class="quiz-options">
                        <div class="quiz-option" onclick="selectAnswer(this, 'q5', true)">
                            A) Inclusion criteria were too restrictive
                        </div>
                        <div class="quiz-option" onclick="selectAnswer(this, 'q5', false)">
                            B) Sites lacked proper equipment
                        </div>
                        <div class="quiz-option" onclick="selectAnswer(this, 'q5', false)">
                            C) Budget was insufficient
                        </div>
                        <div class="quiz-option" onclick="selectAnswer(this, 'q5', false)">
                            D) Competing trials emerged
                        </div>
                    </div>
                    <div class="answer-feedback" id="q5-feedback"></div>
                </div>
            </div>

            <button class="btn btn-success" onclick="submitModuleAssessment()" style="margin-top: 30px; width: 100%;">
                Submit Assessment
            </button>
        </div>

        <div class="nav-buttons">
            <button class="btn btn-secondary" onclick="continueToStep3()">← Previous</button>
            <button class="btn btn-primary" onclick="completeModule1()">Complete Module →</button>
        </div>

        <style>
        .quiz-container {
            margin: 30px 0;
        }

        .answer-feedback {
            margin-top: 15px;
            padding: 15px;
            border-radius: 8px;
            display: none;
        }

        .answer-feedback.show {
            display: block;
        }

        .answer-feedback.correct {
            background: #d1fae5;
            color: #065f46;
            border-left: 5px solid var(--secondary-color);
        }

        .answer-feedback.incorrect {
            background: #fee2e2;
            color: #991b1b;
            border-left: 5px solid var(--danger-color);
        }
        </style>
    `;
}

const quizAnswers = {};

function selectAnswer(element, questionId, isCorrect) {
    // Remove previous selections
    const options = element.parentElement.querySelectorAll('.quiz-option');
    options.forEach(opt => {
        opt.classList.remove('selected', 'correct', 'incorrect');
    });

    // Mark selected
    element.classList.add('selected');
    quizAnswers[questionId] = isCorrect;

    // Show immediate feedback
    const feedbackDiv = document.getElementById(`${questionId}-feedback`);
    feedbackDiv.classList.add('show');
    
    if (isCorrect) {
        element.classList.add('correct');
        feedbackDiv.className = 'answer-feedback show correct';
        feedbackDiv.innerHTML = '✓ Correct! Well done.';
        awardXP(20);
    } else {
        element.classList.add('incorrect');
        feedbackDiv.className = 'answer-feedback show incorrect';
        feedbackDiv.innerHTML = '✗ Not quite. Review the material and try again.';
    }
}

function submitModuleAssessment() {
    const totalQuestions = 5;
    const correctAnswers = Object.values(quizAnswers).filter(a => a === true).length;
    const score = (correctAnswers / totalQuestions) * 100;

    if (Object.keys(quizAnswers).length < totalQuestions) {
        alert('Please answer all questions before submitting.');
        return;
    }

    let message = '';
    let xpBonus = 0;

    if (score >= 80) {
        message = 'Excellent work! You have a strong understanding of feasibility foundations.';
        xpBonus = 100;
    } else if (score >= 60) {
        message = 'Good job! You understand the key concepts. Review the areas you missed.';
        xpBonus = 75;
    } else {
        message = 'You may want to review the module content before proceeding.';
        xpBonus = 50;
    }

    showFeedback(`
        <h3>Assessment Complete!</h3>
        <p>Your Score: <strong>${score}%</strong> (${correctAnswers}/${totalQuestions} correct)</p>
        <p>${message}</p>
    `, score >= 60 ? 'success' : 'warning');

    awardXP(xpBonus);
}

function completeModule1() {
    if (Object.keys(quizAnswers).length < 5) {
        alert('Please complete the assessment before finishing the module.');
        return;
    }

    appState.userProfile.completedModules.push(1);
    awardXP(100);
    unlockBadge('First Steps');
    
    showFeedback(`
        <h2>🎉 Module 1 Complete!</h2>
        <p>Congratulations! You've completed Feasibility Foundations.</p>
        <p>You've earned the <strong>"First Steps"</strong> badge!</p>
        <p>Module 2 is now unlocked.</p>
    `, 'success');

    saveUserProgress();

    setTimeout(() => {
        returnToDashboard();
        unlockModule(2);
    }, 3000);
}

// Helper Functions
function updateStepIndicator(currentStep) {
    const steps = document.querySelectorAll('.step');
    steps.forEach((step, index) => {
        step.classList.remove('active', 'completed');
        if (index + 1 < currentStep) {
            step.classList.add('completed');
        } else if (index + 1 === currentStep) {
            step.classList.add('active');
        }
    });
}

function returnToDashboard() {
    document.getElementById('moduleContent').classList.add('hidden');
    document.getElementById('dashboard').classList.remove('hidden');
    updateProgressDisplay();
}

function unlockModule(moduleNumber) {
    const moduleCards = document.querySelectorAll('.module-card');
    if (moduleCards[moduleNumber - 1]) {
        moduleCards[moduleNumber - 1].classList.remove('locked');
        const statusIcon = moduleCards[moduleNumber - 1].querySelector('.module-status');
        statusIcon.textContent = '🔓';
        statusIcon.classList.add('unlocked');
    }
}

function awardXP(amount) {
    appState.userProfile.xp += amount;
    updateLevel();
    updateProgressDisplay();
    saveUserProgress();
    
    // Show XP notification
    showXPNotification(amount);
}

function updateLevel() {
    const xp = appState.userProfile.xp;
    let newLevel = 'Novice';
    
    if (xp >= levelThresholds['Feasibility Master']) {
        newLevel = 'Feasibility Master';
    } else if (xp >= levelThresholds['Expert']) {
        newLevel = 'Expert';
    } else if (xp >= levelThresholds['Analyst']) {
        newLevel = 'Analyst';
    }
    
    if (newLevel !== appState.userProfile.level) {
        appState.userProfile.level = newLevel;
        showLevelUpNotification(newLevel);
    }
}

function updateProgressDisplay() {
    document.getElementById('totalXP').textContent = appState.userProfile.xp;
    document.getElementById('userLevel').textContent = appState.userProfile.level;
    
    // Update module progress bars
    appState.userProfile.completedModules.forEach(moduleNum => {
        const moduleCards = document.querySelectorAll('.module-card');
        if (moduleCards[moduleNum - 1]) {
            const progressBar = moduleCards[moduleNum - 1].querySelector('.progress-fill');
            if (progressBar) {
                progressBar.style.width = '100%';
            }
        }
    });
}

function unlockBadge(badgeName) {
    if (!appState.userProfile.badges.includes(badgeName)) {
        appState.userProfile.badges.push(badgeName);
        
        // Update badge display
        const badges = document.querySelectorAll('.badge');
        badges.forEach(badge => {
            if (badge.querySelector('.badge-name').textContent === badgeName) {
                badge.classList.remove('locked');
            }
        });
        
        saveUserProgress();
    }
}

function showFeedback(message, type) {
    const feedbackDiv = document.createElement('div');
    feedbackDiv.className = `feedback-box ${type} fade-in`;
    feedbackDiv.innerHTML = message;
    
    const contentArea = document.getElementById('module1-content') || document.getElementById('moduleContent');
    contentArea.insertBefore(feedbackDiv, contentArea.firstChild);
    
    setTimeout(() => {
        feedbackDiv.style.opacity = '0';
        setTimeout(() => feedbackDiv.remove(), 500);
    }, 5000);
}

function showXPNotification(amount) {
    const notification = document.createElement('div');
    notification.className = 'xp-notification';
    notification.textContent = `+${amount} XP`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(135deg, var(--accent-color), #d97706);
        color: white;
        padding: 15px 25px;
        border-radius: 50px;
        font-weight: bold;
        font-size: 1.2rem;
        box-shadow: var(--shadow-xl);
        z-index: 1000;
        animation: slideIn 0.5s ease-out;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transform = 'translateY(-20px)';
        setTimeout(() => notification.remove(), 500);
    }, 2000);
}

function showLevelUpNotification(newLevel) {
    const notification = document.createElement('div');
    notification.className = 'level-up-notification';
    notification.innerHTML = `
        <h2>🎉 Level Up!</h2>
        <p>You are now a <strong>${newLevel}</strong>!</p>
    `;
    notification.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: white;
        padding: 40px;
        border-radius: 20px;
        box-shadow: var(--shadow-xl);
        z-index: 1000;
        text-align: center;
        min-width: 300px;
        animation: fadeIn 0.5s ease-out;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.opacity = '0';
        setTimeout(() => notification.remove(), 500);
    }, 3000);
}

// Local Storage Functions
function saveUserProgress() {
    localStorage.setItem('feasiquest-progress', JSON.stringify(appState));
}

function loadUserProgress() {
    const saved = localStorage.getItem('feasiquest-progress');
    if (saved) {
        const savedState = JSON.parse(saved);
        Object.assign(appState, savedState);
    }
}

// Placeholder functions for other modules
function loadModule2Content(container) {
    container.innerHTML = `
        <div class="module-header-section">
            <button class="btn btn-secondary" onclick="returnToDashboard()">← Back to Dashboard</button>
            <h1>Module 2: Patient Population & Recruitment Feasibility</h1>
            <p class="module-subtitle">Finding and enrolling the right patients</p>
        </div>
        <div class="interactive-card">
            <h2>Coming Soon</h2>
            <p>This module is under development and will be available soon.</p>
            <p>It will cover:</p>
            <ul>
                <li>Epidemiological analysis</li>
                <li>Inclusion/exclusion criteria optimization</li>
                <li>Recruitment strategy development</li>
                <li>Competitive intelligence</li>
                <li>Patient retention planning</li>
            </ul>
        </div>
    `;
}

function loadModule3Content(container) {
    container.innerHTML = `
        <div class="module-header-section">
            <button class="btn btn-secondary" onclick="returnToDashboard()">← Back to Dashboard</button>
            <h1>Module 3: Site Selection & Capability Assessment</h1>
            <p class="module-subtitle">Building your optimal site network</p>
        </div>
        <div class="interactive-card">
            <h2>Coming Soon</h2>
            <p>This module is under development and will be available soon.</p>
        </div>
    `;
}

function loadModule4Content(container) {
    container.innerHTML = `
        <div class="module-header-section">
            <button class="btn btn-secondary" onclick="returnToDashboard()">← Back to Dashboard</button>
            <h1>Module 4: Regulatory & Compliance Feasibility</h1>
            <p class="module-subtitle">Navigating the regulatory maze</p>
        </div>
        <div class="interactive-card">
            <h2>Coming Soon</h2>
            <p>This module is under development and will be available soon.</p>
        </div>
    `;
}

function loadModule5Content(container) {
    container.innerHTML = `
        <div class="module-header-section">
            <button class="btn btn-secondary" onclick="returnToDashboard()">← Back to Dashboard</button>
            <h1>Module 5: Budget & Resource Feasibility</h1>
            <p class="module-subtitle">The financial reality of clinical trials</p>
        </div>
        <div class="interactive-card">
            <h2>Coming Soon</h2>
            <p>This module is under development and will be available soon.</p>
        </div>
    `;
}